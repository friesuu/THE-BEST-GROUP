package LAB2;

public class L2Q5 
{
    public static void main(String[] args) 
    {
        
    }
}
